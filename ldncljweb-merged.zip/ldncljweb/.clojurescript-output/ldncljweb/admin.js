goog.provide('ldncljweb.admin');
goog.require('cljs.core');
goog.require('jayq.core');
goog.require('jayq.util');
ldncljweb.admin.load_post_data = (function load_post_data(id,title){
var success_fn__2970 = (function (data,status,xhr){
jayq.core.$.call(null,"﷐'#post-id").val(data.call(null,"_id"));
jayq.core.$.call(null,"﷐'#post-data").val(data.call(null,"date"));
jayq.core.$.call(null,"﷐'#post-title").val(data.call(null,"title"));
return jayq.core.$.call(null,"﷐'#post-edit-area").val(data.call(null,"body"));
});

jayq.core.$.call(null,"﷐'#post-edit-area").val(cljs.core.str.call(null,"Loading",title,"..."));
return jQuery.ajax(cljs.core.str.call(null,"/admin/posts/",id),cljs.core.ObjMap.fromObject(["﷐'dataType","﷐'success"],{"﷐'dataType":"json","﷐'success":success_fn__2970}));
});
ldncljweb.admin.load_posts_success_fn = (function load_posts_success_fn(data,status,xhr){
var posts__2971 = cljs.core.map.call(null,ldncljweb.admin.post_format_fn,data);

ldncljweb.admin.posts_list_element.append(posts__2971.join(""));
return jayq.core.$.call(null,"#posts-list div").click((function (){
ldncljweb.admin.remove_class.call(null,jayq.core.$.call(null,"#posts-list div"),"selected");
var el__2972 = this;

ldncljweb.admin.add_class.call(null,el__2972,"selected");
return ldncljweb.admin.load_post_data.call(null,el__2972.attr("data-id"),el__2972.text());
}));
});
ldncljweb.admin.load_posts = (function load_posts(){
var posts_list_element__2973 = jayq.core.$.call(null,"﷐'#posts-list");
var post_format_fn__2974 = (function (k,post){
return cljs.core.str.call(null,"<div data-id=\"",post.call(null,"id_"),"\">",jayq.core.$.call(null,"div").text(post.call(null,"title")).html(),"</div>");
});
var ajax_url__2975 = "/admin/posttitles";
var ajax_params__2976 = cljs.core.ObjMap.fromObject(["﷐'dataType","﷐'success"],{"﷐'dataType":"json","﷐'success":ldncljweb.admin.load_posts_success_fn});

return jQuery.ajax(ajax_url__2975,ajax_params__2976);
});
ldncljweb.admin.clear_post_fields = (function clear_post_fields(){
jayq.core.$.call(null,"﷐'#post-id").val("");
jayq.core.$.call(null,"﷐'#post-title").val("");
jayq.core.$.call(null,"﷐'#post-date").val("");
jayq.core.$.call(null,"﷐'#post-edit-area").val("");
jayq.core.remove_class.call(null,jayq.core.$.call(null,"#posts-list div"),"selected");
return jayq.util.log.call(null,"Our clear-post-fields called");
});
ldncljweb.admin.post_save_click = (function post_save_click(){
var post_id_element__2977 = jayq.core.$.call(null,"﷐'#post-id");
var post_id__2978 = post_id_element__2977.val();
var ajax_params__2979 = cljs.core.ObjMap.fromObject(["﷐'data","﷐'success"],{"﷐'data":cljs.core.ObjMap.fromObject(["﷐'title","﷐'date","﷐'body"],{"﷐'title":jayq.core.$.call(null,"﷐'#post-title").val(),"﷐'date":jayq.core.$.call(null,"﷐'#post-date").val(),"﷐'body":jayq.core.$.call(null,"﷐'#post-edit-area").val()}),"﷐'success":(function (){
return ldncljweb.admin.load_posts.call(null);
})});

if(cljs.core.truth_(cljs.core._EQ_.call(null,post_id__2978.length,0)))
{return jQuery.ajax(cljs.core.assoc.call(null,ajax_params__2979,"﷐'url","/admin/posts/new","﷐'type","POST"));
} else
{return jQuery.ajax(cljs.core.assoc.call(null,ajax_params__2979,"﷐'url",cljs.core.str.call(null,"/admin/posts/",post_id__2978),"﷐'type","PUT"));
}
});
ldncljweb.admin.main = (function main(){
return jayq.core.$.call(null,(function (){
return jayq.core.$.call(null,"﷐'#post-save").button().click(ldncljweb.admin.post_save_click);
}));
});
goog.exportSymbol('ldncljweb.admin.main', ldncljweb.admin.main);
