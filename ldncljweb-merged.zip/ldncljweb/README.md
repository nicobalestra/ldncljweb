ldncljweb
=========

1) Install mongo db (http://www.mongodb.org/) running on the default port.

2) In one command window:

    lein deps

    lein run

3) In a second command window:

	lein cljsbuild auto

4) Then point your browser at http://localhost:8080
